/*
 * Exercício: Controle e Estatísticas de Base de Dados - AED’s I.
 * File:   controle.cpp
 * Autor: Leticia Santos Alves e Luiz Gustavo Custódio Leite.
 * RA: 2025.1.08.016 e 2025.1.08.031.
 * Local: Alfenas - MG.
 * Disciplina: AED’s I - Prática.
 * Data: 08 de junho de 2025.
 * Objetivo: Desenvolver um sistema para gerenciar até 200 imóveis, permitindo a leitura e gravação em arquivo, inclusão, exclusão
 * e busca por faixa de valor, características específicas ou número de quartos e suítes.
 */

#include <iostream>
#include <fstream>
#include <string.h>
#include <iomanip>
#include <sstream>

using namespace std;

// Estrutura que representa um imóvel com suas características.
struct Imovel {
    string tipo, finalidade, endereco, bairro, cidade;
    float area, valor, iptu;
    int quartos, suites, banheiros, vagas;
    string cozinha, sala, varanda, area_servico, piso, conservacao;
    string armarios, ar_condicionado, aquecedor, ventilador;
};

// Array estático para armazenar os imóveis
Imovel imoveis[200];
int num_imoveis = 0; // Contador de imóveis cadastrados

// Define o número máximo de imóveis.
const int MAX_IMOVEIS = 200;

// Lê o arquivo com as características de cada imóvel.
void lerArquivo(const string& caminho) {
    ifstream arquivo(caminho);
    if (!arquivo) {
        cerr << "Erro ao abrir o arquivo." << endl;
        return;
    }

    string linha;
    while (getline(arquivo, linha)) { // Lê o arquivo linha por linha até acabar.
        if (linha.find("fim") != string::npos || num_imoveis >= MAX_IMOVEIS) break; // Para de ler quando encontra o "fim".
        Imovel i;
        istringstream iss(linha);
        // Extrai os dados da linha para os campos do objeto.
        iss >> i.tipo >> i.finalidade >> i.endereco >> i.bairro >> i.cidade >> i.area
            >> i.valor >> i.iptu >> i.quartos >> i.suites >> i.banheiros >> i.vagas
            >> i.cozinha >> i.sala >> i.varanda >> i.area_servico >> i.piso >> i.conservacao
            >> i.armarios >> i.ar_condicionado >> i.aquecedor >> i.ventilador;
        imoveis[num_imoveis++] = i;
    }
    arquivo.close();
}

void salvarArquivo(const string& caminho) {
    ofstream arquivo(caminho);
    for (int i = 0; i < num_imoveis; ++i) {
        arquivo << imoveis[i].tipo << " " << imoveis[i].finalidade << " " << imoveis[i].endereco << " " << imoveis[i].bairro << " " << imoveis[i].cidade << " "
                << imoveis[i].area << " " << imoveis[i].valor << " " << imoveis[i].iptu << " " << imoveis[i].quartos << " " << imoveis[i].suites << " "
                << imoveis[i].banheiros << " " << imoveis[i].vagas << " " << imoveis[i].cozinha << " " << imoveis[i].sala << " " << imoveis[i].varanda << " "
                << imoveis[i].area_servico << " " << imoveis[i].piso << " " << imoveis[i].conservacao << " " << imoveis[i].armarios << " "
                << imoveis[i].ar_condicionado << " " << imoveis[i].aquecedor << " " << imoveis[i].ventilador << "\n";
    }
    arquivo << "fim\n";
    arquivo.close();
}

void incluirimo() { // Adicionar um novo imóvel.
    if (num_imoveis >= MAX_IMOVEIS) { // Caso atinja o limite de 200.
        cout << "Base de dados cheia." << endl;
        return;
    }
    Imovel i;
    cout << "Tipo do imóvel (use underline, se necessário): "; cin >> i.tipo;
    cout << "Finalidade: "; cin >> i.finalidade;
    cout << "Endereço (use underline, se necessário): "; cin >> i.endereco;
    cout << "Bairro (use underline, se necessário): "; cin >> i.bairro;
    cout << "Cidade (use underline, se necessário): "; cin >> i.cidade;
    cout << "Área (em m²): "; cin >> i.area;
    cout << "Valor (R$): "; cin >> i.valor;
    cout << "IPTU (R$): "; cin >> i.iptu;
    cout << "Número de quartos: "; cin >> i.quartos;
    cout << "Número de suítes: "; cin >> i.suites;
    cout << "Número de banheiros: "; cin >> i.banheiros;
    cout << "Número de vagas de garagem: "; cin >> i.vagas;
    cout << "Tem cozinha?: "; cin >> i.cozinha;
    cout << "Tem sala?: "; cin >> i.sala;
    cout << "Tem varanda?: "; cin >> i.varanda;
    cout << "Tem área de serviço?: "; cin >> i.area_servico;
    cout << "Tipo de piso (ex: ceramica, porcelanato): "; cin >> i.piso;
    cout << "Estado de conservação: "; cin >> i.conservacao;
    cout << "Tem armários embutidos?: "; cin >> i.armarios;
    cout << "Tem ar-condicionado?: "; cin >> i.ar_condicionado;
    cout << "Tem aquecedor?: "; cin >> i.aquecedor;
    cout << "Tem ventilador?: "; cin >> i.ventilador;
    
    imoveis[num_imoveis++] = i;
    cout << "Imóvel adicionado com sucesso." << endl;
}

void verrua() { // Ver todas as caracteristicas do imóvel, ou apaga-lo, a partir da rua.
    string rua;
    cout << "Digite a rua do imóvel: "; cin >> rua;
    int cont = 0;
    for (int i = 0; i < num_imoveis; ++i) { // Exibe os imóveis da rua com índice.
        if (imoveis[i].endereco == rua) {
            cont++;
            cout << "\nImóvel " << cont << endl;
            cout << "Tipo: " << imoveis[i].tipo << endl;
            cout << "Finalidade: " << imoveis[i].finalidade << endl;
            cout << "Endereço: " << imoveis[i].endereco << endl;
            cout << "Bairro: " << imoveis[i].bairro << endl;
            cout << "Cidade: " << imoveis[i].cidade << endl;
            cout << fixed << setprecision(2);
            cout << "Área: " << imoveis[i].area << " m²" << endl;
            cout << "Valor: R$" << imoveis[i].valor << endl;
            cout << "IPTU: R$" << imoveis[i].iptu << endl;
            cout << "Quartos: " << imoveis[i].quartos << endl;
            cout << "Suítes: " << imoveis[i].suites << endl;
            cout << "Banheiros: " << imoveis[i].banheiros << endl;
            cout << "Vagas: " << imoveis[i].vagas << endl;
            cout << "Cozinha: " << imoveis[i].cozinha << endl;
            cout << "Sala: " << imoveis[i].sala << endl;
            cout << "Varanda: " << imoveis[i].varanda << endl;
            cout << "Área de Serviço: " << imoveis[i].area_servico << endl;
            cout << "Piso: " << imoveis[i].piso << endl;
            cout << "Conservação: " << imoveis[i].conservacao << endl;
            cout << "Armários Embutidos: " << imoveis[i].armarios << endl;
            cout << "Ar-condicionado: " << imoveis[i].ar_condicionado << endl;
            cout << "Aquecedor: " << imoveis[i].aquecedor << endl;
            cout << "Ventilador: " << imoveis[i].ventilador << endl;
            cout << "============================" << endl;
        }
    }

    if (cont == 0) { // Caso não seja encontrado nenhum imóvel,
        cout << "Nenhum imóvel encontrado nessa rua." << endl;
        return;
    }
    int opcao; 
    cout << "Digite o número do imóvel que deseja excluir (0 para nenhum): "; cin >> opcao;
    if (opcao <= 0 || opcao > cont) {
        cout << "Operação cancelada." << endl;
        return;
    }
    int atual = 0;
    for (int i = 0; i < num_imoveis; ++i) { // Exluir o imóvel.
        if (imoveis[i].endereco == rua) {
            atual++;
            if (atual == opcao) {
                // Move todos os elementos após o índice 'i' uma posição para trás
                for (int j = i; j < num_imoveis - 1; ++j) {
                    imoveis[j] = imoveis[j + 1];
                }
                num_imoveis--;
                cout << "Imóvel excluído com sucesso." << endl;
                break;
            } 
        } 
    }
}

void buscarvalor() { // Buscar um imóvel que encaixe nos valores colocados pelo usuário.
    float min, max;
    cout << "Digite o valor mínimo: "; cin >> min;
    cout << "Digite o valor máximo: "; cin >> max;
    if (min > max) {
        cout << "Valor mínimo não pode ser maior que o máximo.";
        return;
    }

    bool encontrado = false;
    for (int i = 0; i < num_imoveis; ++i) {
        if (imoveis[i].valor >= min && imoveis[i].valor <= max) {
            encontrado = true;
            cout << "\nImóvel encontrado:\n";
            cout << "Tipo: " << imoveis[i].tipo << "\nEndereço: " << imoveis[i].endereco << "\nBairro: " << imoveis[i].bairro
                 << "\nCidade: " << imoveis[i].cidade << "\nValor: R$" << fixed << setprecision(2) << imoveis[i].valor << "\n";
            cout << "Área: " << imoveis[i].area << " m², Quartos: " << imoveis[i].quartos << ", Suítes: " << imoveis[i].suites << "\n";
            cout << "==============================" << endl;
        }
    }
    if (!encontrado) {
        cout << "Nenhum imóvel encontrado nessa faixa de preço." << endl;
    }
}

void buscarcaracter() { // Busca o imóvel com base nas características que serão preenchidas pelo usuário.
    string arm, ar, aq, vent; 
    cout << "Digite 'sim', 'não' ou 'qualquer' para os seguintes critérios:\n";
    cout << "Armários embutidos: "; cin >> arm;
    cout << "Ar-condicionado: "; cin >> ar;
    cout << "Aquecedor: "; cin >> aq;
    cout << "Ventilador: "; cin >> vent;

    bool encontrado = false;
    for (int i = 0; i < num_imoveis; ++i) {
        bool cond_arm = (arm == "qualquer") || (imoveis[i].armarios == arm);
        bool cond_ar = (ar == "qualquer") || (imoveis[i].ar_condicionado == ar);
        bool cond_aq = (aq == "qualquer") || (imoveis[i].aquecedor == aq);
        bool cond_vent = (vent == "qualquer") || (imoveis[i].ventilador == vent);

        if (cond_arm && cond_ar && cond_aq && cond_vent) {
            encontrado = true;
            cout << "\nImóvel encontrado:" << endl;
            cout << "Tipo: " << imoveis[i].tipo << "\nEndereço: " << imoveis[i].endereco << "\nBairro: " << imoveis[i].bairro
                 << "\nCidade: " << imoveis[i].cidade << "\nValor: R$" << fixed << setprecision(2) << imoveis[i].valor << "\n";
            cout << "Armários: " << imoveis[i].armarios << ", Ar-condicionado: " << imoveis[i].ar_condicionado
                 << ", Aquecedor: " << imoveis[i].aquecedor << ", Ventilador: " << imoveis[i].ventilador << "\n";
            cout << "===========================\n";
        }
    }
    if (!encontrado) { // Caso nenhum imóvel seja encontrado.
        cout << "Nenhum imóvel foi encontrado com essas características." << endl;
    }
}

void buscarquartos() { // Buscar um imóvel com base no número de quartos e suítes colocados pelo usuário.
    int quartos, suites;
    cout << "Digite a quantidade de quartos: "; cin >> quartos;
    cout << "Digite a quantidade de suítes: "; cin >> suites;

    bool encontrado = false;
    for (int i = 0; i < num_imoveis; ++i) {
        if (imoveis[i].quartos == quartos && imoveis[i].suites == suites) {
            encontrado = true;
            cout << "Tipo: " <<  imoveis[i].tipo << "\nEndereço: " <<  imoveis[i].endereco << "\nBairro: " <<  imoveis[i].bairro
                 << "\nCidade: " <<  imoveis[i].cidade << "\nValor: R$" << fixed << setprecision(2) <<  imoveis[i].valor << "\n";
            cout << "Área: " <<  imoveis[i].area << " m², Quartos: " <<  imoveis[i].quartos << ", Suítes: " <<  imoveis[i].suites << "\n";
            cout << "===========================================" << endl;
        }
    }

    if (!encontrado) {
        cout << "Nenhum imóvel encontrado com os critérios informados.\n";
    }
}

void relatorioestati(){ // Relatorio estatistico.
    int total = num_imoveis; // Define o valor de total, com base no número de imóveis.
    int venda = 0, aluguel = 0, temporada = 0, casassuite = 0, pisosCeramica = 0, salas = 0;
    for (int i = 0; i < num_imoveis; ++i) {
        if (imoveis[i].finalidade == "venda"){
            venda++;
        } else if (imoveis[i].finalidade == "aluguel"){
            aluguel++;
        } else if (imoveis[i].finalidade == "temporada"){
            temporada++;
        } 
        if (imoveis[i].tipo == "casa" && imoveis[i].suites > 0){
            casassuite++;
        } 
        if (imoveis[i].tipo == "sala_comercial") {
            salas++;
            if (imoveis[i].piso == "cerâmica") pisosCeramica++;
        }
    } 
    
    cout << fixed << setprecision(2);
    cout << "% de imóveis a venda: " << (float) venda / total * 100 << "%" << endl;
    cout << "% de imóveis para aluguel: " << (float) aluguel / total * 100 << "%" << endl;
    cout << "% de imóveis por temporada: " << (float) temporada / total * 100 << "%" << endl;
    cout << "% de casas com suíte: " << (float) casassuite / total * 100 << "%" << endl;
    if (salas > 0) {
        cout << "% de salas comerciais com cerâmica: " <<  (float) pisosCeramica / salas * 100 << "%" << endl;
    }
}

void listimo() { // Lista, completamente, todos os imóveis presentes.
    cout << "\n======Lista Completa de Imóveis======\n";
    for (int i = 0; i < num_imoveis; ++i) {
        cout << "\nImóvel #" << i + 1 << ":" << endl;
        cout << "Tipo: " << imoveis[i].tipo << endl;
        cout << "Finalidade: " << imoveis[i].finalidade << endl;
        cout << "Endereço: " << imoveis[i].endereco << endl;
        cout << "Bairro: " << imoveis[i].bairro << endl;
        cout << "Cidade: " << imoveis[i].cidade << endl;
        cout << fixed << setprecision(2);
        cout << "Área: " << imoveis[i].area << " m²" << endl;
        cout << "Valor: R$" << imoveis[i].valor << endl;
        cout << "IPTU: R$" << imoveis[i].iptu << endl;
        cout << "Quartos: " << imoveis[i].quartos << endl;
        cout << "Suítes: " << imoveis[i].suites << endl;
        cout << "Banheiros: " << imoveis[i].banheiros << endl;
        cout << "Vagas: " << imoveis[i].vagas << endl;
        cout << "Cozinha: " << imoveis[i].cozinha << endl;
        cout << "Sala: " << imoveis[i].sala << endl;
        cout << "Varanda: " << imoveis[i].varanda << endl;
        cout << "Área de Serviço: " << imoveis[i].area_servico << endl;
        cout << "Piso: " << imoveis[i].piso << endl;
        cout << "Conservação: " << imoveis[i].conservacao << endl;
        cout << "Armários Embutidos: " << imoveis[i].armarios << endl;
        cout << "Ar-condicionado: " << imoveis[i].ar_condicionado << endl;
        cout << "Aquecedor: " << imoveis[i].aquecedor << endl;
        cout << "Ventilador: " << imoveis[i].ventilador << endl;
        cout << "\n============================" << endl;
    }
    if (num_imoveis == 0) {
        cout << "Nenhum imóvel cadastrado.\n";
    }
}

void menu() {
    int option;
    do {
        cout << "\n========Menu de Opções========" << endl;
        cout << "1. Incluir imóvel;" << endl; // case 1.
        cout << "2. Ver/excluir por rua;" << endl; // case 2.
        cout << "3. Buscar por faixa de valor;" << endl; // case 3.
        cout << "4. Buscar por características;" << endl; // case 4.
        cout << "5. Buscar por quartos e suítes;" << endl; // case 5.
        cout << "6. Relatório estatístico;" << endl; // case 6.
        cout << "7. Listar todos os imóveis;" << endl; // case 7.
        cout << "0. Sair." << endl; // case 0.
        cout << "Insira uma opção: ";
        cin >> option;
        
        switch(option) { 
            case 1: incluirimo(); 
                break;
            case 2: verrua(); 
                break;
            case 3: buscarvalor(); 
                break;
            case 4: buscarcaracter(); 
                break;
            case 5: buscarquartos(); 
                break;
            case 6: relatorioestati(); 
                break;
            case 7: listimo(); 
                break;
            case 0: cout << "Finalizando o programa...\nA Luthor-Tech agradece."; 
                break;
            default: cout << "Opção inválida.\n";
        }
    } while (option != 0);
}

// Salva o arquivo.
int main() {
    string caminho = "BD_Imoveis2.txt"; 
    lerArquivo(caminho);
    cout << "Seja bem vindo ao sistema de Imóveis\nda Luthor-Tech!" << endl;
    menu();
    salvarArquivo(caminho);
    return 0;
}