========================================================
        SISTEMA DE GESTÃO DE IMÓVEIS - C++
========================================================

Desenvolvido por: Leticia Santos Alves e Luiz Gustavo Custódio Leite.
RA: 2025.1.08.016 e 2025.1.08.031. 
Disciplina: AED’s I - Prática  
Instituição: Universidade Federal de Alfenas

-----------------------------------
DESCRIÇÃO DO PROJETO
-----------------------------------
Este sistema em C++ permite a gestão de até 200 imóveis registrados em um arquivo-texto. O aplicativo realiza operações como:
- Leitura de dados de imóveis a partir de um arquivo.
- Inclusão de novos imóveis.
- Exclusão de imóveis existentes.
- Busca por imóveis com base em diferentes critérios.

Cada imóvel é descrito por 22 campos, entre eles: ID, tipo, endereço, área, valor, número de quartos, e outros atributos relevantes.

----------------------------------
FUNCIONALIDADES DO PROJETO
----------------------------------
O menu principal do programa oferece as seguintes opções:
1. Incluir novo imóvel
    Adiciona um novo registro ao final do vetor.

2. Buscar imóvel pela rua e excluir 
    Localiza um imóvel pelo endereço (rua). Se encontrado, o usuário pode optar por excluí-lo.

3. Buscar imóveis por faixa de valor
    Permite buscar imóveis com valores dentro de um intervalo definido, seja para aluguel ou temporada.

4. Buscar por características específicas
    Permite listar imóveis com determinadas características como armários, ar-condicionado, aquecedor e ventilador.

5. Buscar por quartos e suítes 
    Lista imóveis com número mínimo de quartos e/ou suítes definidos pelo usuário.

6. Estatísticas gerais
    Calcula e exibe:
   - Porcentagens de imóveis por finalidade (venda, aluguel, temporada);
   - Porcentagem de casas com suítes;
   - Porcentagem de salas comerciais com piso cerâmico.

7. Listar todos os imóveis disponíveis
    Exibe os dados de todos os imóveis armazenados no vetor (exceto a linha “fim”).

0. Sair e salvar alterações no arquivo
    Todos os dados são regravados no arquivo de entrada original.

------------------------------------------
OBSERVAÇÕES IMPORTANTES
------------------------------------------
- Use underlines (_) no lugar de espaços em campos textuais.
- Valores decimais devem usar ponto.
- O sistema não valida duplicatas.

*OBSERVAÇÕES FINAIS:
Este projeto foi desenvolvido para fins acadêmicos, demonstrando conceitos de estruturas de dados, manipulação de arquivos e programação modular em C++.

